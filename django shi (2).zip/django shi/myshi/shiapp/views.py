from django.shortcuts import render

def index(request):
    context={}
    return render(request,"shiapp/index.html",context)

def Contact(request):
    return render(request, 'shiapp/contact.html')

def Games(request):
    return render (request,'shiapp/games.html')
    

def Edu(request):
    return render (request,'shiapp/edu.html')


def Toggle(request):
    return render(request, 'shiapp/toggle.html')
