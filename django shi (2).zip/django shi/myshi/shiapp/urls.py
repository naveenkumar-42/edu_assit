from . import views
from django.urls import path 

urlpatterns = [
    path("",views.index, name="index"),
    path("",views.Edu, name="edu"),
    path("",views.Contact, name="contact"),
    path("",views.Toggle, name="toggle"),
]