from django.contrib import admin
from django.urls import path, include
from shiapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include("shiapp.urls")), 
    path('home/', views.index, name='index'),
    path('contact/', views.Contact, name='contact'),
    path('games/',views.Games,name='games'),
    path('toggle/',views.Toggle,name='toggle'),
    path('edu/',views.Edu,name='edu')
]